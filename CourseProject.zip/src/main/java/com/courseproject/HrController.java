package com.courseproject;

import javafx.animation.FadeTransition;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

public class HrController {

    @FXML
    private AnchorPane tableBlock;

    @FXML
    private AnchorPane statsBlock;

    @FXML
    private AnchorPane profileBlock;

    @FXML
    private PieChart genderChart;

    @FXML
    private ComboBox<String> sr_st;

    @FXML
    private Button addUser;

    @FXML
    private Button apply;

    @FXML
    private Text greetings;

    @FXML
    private TableView<User> hrtable;

    @FXML
    private Button logout;

    @FXML
    private Button editUser;

    @FXML
    private Button refresh;

    @FXML
    private Button emp_table;

    @FXML
    private Button profile_but;

    @FXML
    private Button stats_but;

    @FXML
    private TableColumn<User, Integer> tableBonus;

    @FXML
    private TableColumn<User, Integer> tableStatus;

    @FXML
    private TableColumn<User, Integer> tableId;

    @FXML
    private TableColumn<User, String> tableLogin;

    @FXML
    private TableColumn<User, String> tableName;

    @FXML
    private TableColumn<User, String> tableGender;

    @FXML
    private TableColumn<User, String> tablePos;

    @FXML
    private TableColumn<User, String> tableRole;

    @FXML
    private TableColumn<User, Integer> tableSalary;

    ObservableList<User> usersList = FXCollections.observableArrayList();
    ObservableList<String> statusList = FXCollections.observableArrayList("Works", "Fired");

    @FXML
    protected void initialize() throws SQLException {
        sr_st.setValue("Works");
        setTableWorks();
        sr_st.setItems(statusList);

        profile_but.setOnAction(actionEvent -> {
            profileBlock.setVisible(true);
            statsBlock.setVisible(false);
            tableBlock.setVisible(false);
        });
        stats_but.setOnAction(actionEvent -> {
            profileBlock.setVisible(false);
            statsBlock.setVisible(true);
            tableBlock.setVisible(false);
        });
        emp_table.setOnAction(actionEvent -> {
            profileBlock.setVisible(false);
            statsBlock.setVisible(false);
            tableBlock.setVisible(true);
        });
        sr_st.setOnAction(actionEvent -> {
            if (sr_st.getValue().equals("Works")) {
                try {
                    hrtable.getItems().clear();
                    setTableWorks();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            } else {
                try {
                    hrtable.getItems().clear();
                    setTableNotWorks();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        });
        greetings.setText("HRManager Panel");
        editUser.setOnAction(event -> {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(this.getClass().getResource("edituser.fxml"));

            try {
                loader.load();
            } catch (IOException e) {
                e.printStackTrace();
            }

            Parent root = loader.getRoot();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));

            stage.show();
        });

        addUser.setOnAction(event -> {
            System.out.println(Controller.userName+" add user");

            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(this.getClass().getResource("adduser.fxml"));

            try {
                loader.load();
            } catch (IOException e) {
                e.printStackTrace();
            }

            Parent root = loader.getRoot();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));

            stage.show();
        });

        refresh.setOnAction(event -> {
            try {
                hrtable.getItems().clear();
                setHrtable();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        });

        logout.setOnAction(event -> {
            System.out.println(Controller.userName+"exit");
            logout.getScene().getWindow().hide();

            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(this.getClass().getResource("log_in.fxml"));

            try {
                loader.load();
            } catch (IOException e) {
                e.printStackTrace();
            }

            Parent root = loader.getRoot();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));

            stage.show();
        });
    }

    @FXML
    private void setHrtable() throws SQLException {
        DatabaseHandler dbHandler = new DatabaseHandler();

        ResultSet result = dbHandler.getAllUser();

        while(true) {
            try {
                if (!result.next()) break;
            } catch (SQLException e) {
                e.printStackTrace();
            }
            usersList.add(new User(result.getInt("id"),
                    result.getString("name"),
                    result.getString("login"),
                    result.getString("password"),
                    result.getInt("salary"),
                    result.getString("role"),
                    result.getString("pos"),
                    result.getInt("bonus"),
                    result.getString("gender"),
                    result.getString("status")));

        }
        tableId.setCellValueFactory(new PropertyValueFactory<>("id"));
        tableName.setCellValueFactory(new PropertyValueFactory<>("name"));
        tableLogin.setCellValueFactory(new PropertyValueFactory<>("login"));
        tableGender.setCellValueFactory(new PropertyValueFactory<>("gender"));
        tableSalary.setCellValueFactory(new PropertyValueFactory<>("salary"));
        tableRole.setCellValueFactory(new PropertyValueFactory<>("role"));
        tablePos.setCellValueFactory(new PropertyValueFactory<>("pos"));
        tableBonus.setCellValueFactory(new PropertyValueFactory<>("bonus"));
        tableStatus.setCellValueFactory(new PropertyValueFactory<>("status"));

        tableId.setSortType(TableColumn.SortType.DESCENDING);

        hrtable.setItems(usersList);
    }

    @FXML
    private void setTableWorks() throws SQLException {
        DatabaseHandler dbHandler = new DatabaseHandler();

        ResultSet result = dbHandler.getAllUser();

        while(true) {
            try {
                if (!result.next()) break;
            } catch (SQLException e) {
                e.printStackTrace();
            }
            if (result.getString("status").equals("Works")) {
                usersList.add(new User(result.getInt("id"),
                        result.getString("name"),
                        result.getString("login"),
                        result.getString("password"),
                        result.getInt("salary"),
                        result.getString("role"),
                        result.getString("pos"),
                        result.getInt("bonus"),
                        result.getString("gender"),
                        result.getString("status")));
            }

        }
        tableId.setCellValueFactory(new PropertyValueFactory<>("id"));
        tableName.setCellValueFactory(new PropertyValueFactory<>("name"));
        tableLogin.setCellValueFactory(new PropertyValueFactory<>("login"));
        tableGender.setCellValueFactory(new PropertyValueFactory<>("gender"));
        tableSalary.setCellValueFactory(new PropertyValueFactory<>("salary"));
        tableRole.setCellValueFactory(new PropertyValueFactory<>("role"));
        tablePos.setCellValueFactory(new PropertyValueFactory<>("pos"));
        tableBonus.setCellValueFactory(new PropertyValueFactory<>("bonus"));
        tableStatus.setCellValueFactory(new PropertyValueFactory<>("status"));

        tableId.setSortType(TableColumn.SortType.DESCENDING);

        hrtable.setItems(usersList);
    }


    @FXML
    private void setTableNotWorks() throws SQLException {
        DatabaseHandler dbHandler = new DatabaseHandler();

        ResultSet result = dbHandler.getAllUser();

        while(true) {
            try {
                if (!result.next()) break;
            } catch (SQLException e) {
                e.printStackTrace();
            }
            if (!result.getString("status").equals("Works")) {
                usersList.add(new User(result.getInt("id"),
                        result.getString("name"),
                        result.getString("login"),
                        result.getString("password"),
                        result.getInt("salary"),
                        result.getString("role"),
                        result.getString("pos"),
                        result.getInt("bonus"),
                        result.getString("gender"),
                        result.getString("status")));
            }

        }
        tableId.setCellValueFactory(new PropertyValueFactory<>("id"));
        tableName.setCellValueFactory(new PropertyValueFactory<>("name"));
        tableLogin.setCellValueFactory(new PropertyValueFactory<>("login"));
        tableGender.setCellValueFactory(new PropertyValueFactory<>("gender"));
        tableSalary.setCellValueFactory(new PropertyValueFactory<>("salary"));
        tableRole.setCellValueFactory(new PropertyValueFactory<>("role"));
        tablePos.setCellValueFactory(new PropertyValueFactory<>("pos"));
        tableBonus.setCellValueFactory(new PropertyValueFactory<>("bonus"));
        tableStatus.setCellValueFactory(new PropertyValueFactory<>("status"));

        tableId.setSortType(TableColumn.SortType.DESCENDING);

        hrtable.setItems(usersList);
    }
}
