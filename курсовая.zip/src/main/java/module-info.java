module com.courseproject {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;

    opens com.courseproject to javafx.fxml;
    exports com.courseproject;
}